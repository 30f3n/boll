// انسخ هذا الملف إلى firebase-config.js وضع بيانات مشروعك الحقيقية محلياً
// ملاحظة: ملف firebase-config.js مضاف إلى .gitignore حتى لا يُرفع إلى GitHub

export const firebaseConfig = {
  apiKey: "YOUR_FIREBASE_API_KEY",
  authDomain: "YOUR_PROJECT_ID.firebaseapp.com",
  projectId: "YOUR_PROJECT_ID",
  storageBucket: "YOUR_PROJECT_ID.firebasestorage.app",
  messagingSenderId: "YOUR_MESSAGING_SENDER_ID",
  appId: "YOUR_APP_ID",
  measurementId: "YOUR_MEASUREMENT_ID"
};

export const appId = "YOUR_APP_ID_OR_PROJECT_ID";
