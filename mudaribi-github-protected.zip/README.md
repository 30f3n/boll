# مُدَرِّبِي — إدارة التشكيلات والحجوزات الرياضية

نسخة جاهزة للرفع على **GitHub** مع فصل إعدادات **Firebase** وحماية الصلاحيات.

## خطوات الإعداد والأمان قبل النشر

1. **إنشاء ملف الإعدادات المحلي:**
   انسخ الملف `firebase-config.example.js` باسم `firebase-config.js` وضع بداخله بيانات مشروعك الفعلية.
   الملف `firebase-config.js` مدرج مسبقاً داخل `.gitignore` ولن يُرفع إلى المستودع العام.

2. **حماية تسجيل دخول الإدارة (Firebase Authentication):**
   - من **Firebase Console** ← **Authentication** ← **Sign-in method** فعّل **Email/Password**.
   - من **Users** أنشئ حساب المدرب (البريد الإلكتروني + كلمة المرور).

3. **تطبيق قواعد الأمان (Firestore Security Rules):**
   - افتح **Firestore Database** ← **Rules** والصق محتوى ملف `firestore.rules` بعد استبدال `YOUR_ADMIN_EMAIL` ببريد حساب الإدارة.
